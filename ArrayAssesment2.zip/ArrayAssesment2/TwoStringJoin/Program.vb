Imports System

Module Program
    Sub Main(args As String())

        Dim array1() As String = {"Rekha", "Ram", "Srinivas"}
        Dim name As New List(Of String)
        Dim array2() As String = {"Rekha", "Ramya", "Srinvas"}

        Dim list As List(Of String) = New List(Of String)(array1.Intersect(array2).ToArray())

        For Each s As String In list


            Console.WriteLine(s)
        Next
    End Sub
End Module
