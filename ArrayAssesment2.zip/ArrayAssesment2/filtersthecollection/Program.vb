Imports System

Module Program
    Sub Main(args As String())
        Dim list As New ArrayList()
        list.Add(1)
        list.Add("Ramya")
        list.Add(3)
        list.Add("Rekha")
        list.Add(5)


        Dim filteredlist As New ArrayList()
        For Each item As Integer In list
            If TypeOf item Is Integer Then
                intListFiltered.Add(item)
            End If
        Next

    End Sub
End Module
