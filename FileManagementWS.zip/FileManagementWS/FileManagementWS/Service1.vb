﻿Imports NLog
#Region "Service1"
''' <summary>
''' Service1 to start the service and stop the service.Window service will deploy in every 15 mints.
''' Declare the logfile and delegates for pointing function .Calling the class with object
''' </summary>
Public Class Service1
    Dim processingCsv As ManagingCsv = New ManagingCsv
    Private _timer As System.Timers.Timer
    Public logger As ILogger = LogManager.GetCurrentClassLogger()
#Region "Protected Methods"
    ''' <summary>
    ''' To start the window service in every 15 minutes
    ''' </summary>

    Protected Overrides Sub OnStart(ByVal args() As String)

        logger.Info("Window Service Started...")
        'set the timer for 15 mints
        _timer = New System.Timers.Timer(10000)
        AddHandler _timer.Elapsed, AddressOf processingCsv.ReadFile
        _timer.Enabled = True

        processingCsv.ReadFile()


    End Sub
#End Region
#Region "Protected Methods"
    ''' <summary>
    ''' To stop the window service when you want to stop
    ''' </summary>
    Protected Overrides Sub OnStop()
        logger.Info("Window Service Stopped ..")
        _timer.Dispose()
    End Sub

#End Region
End Class
#End Region
