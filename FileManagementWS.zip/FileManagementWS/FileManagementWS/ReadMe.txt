﻿Window Service Task:
Step 1.Create a folder in D drive.
Create 3 folders in it. 
1. Unprocessed
2. Processed
3. Error 
Step 2.The DB table structure is same as existing StudentData tables. 
Step 3.Create a Windows service and deploy in your machine. It should run every 15 mins. 
Step 4.The service will read all csv files placed in Unprocessed folder. Process the data and move data to tables.
Step 5.The logic need to verify if columns matching as per requirement, if columns not matching, move that csv file to Error folder.
Step 6.If any file placed in Unprocessed folder which is not csv, the file should be moved to Error folder and continue with next files.
Step 7.After each 15 min service run, the unprocessed folder should become empty.
Step 8.Once the file is moved to Processed or Error folder, Datetime should be appended to file name.
Step 9.If a csv contains same Student Id and marks for same subject, consider this latest marks and over write DB marks.
Step 10.If csv contains same Student Id and marks for same subject in one file, consider latest marks.
Step 11.Proper exception handling to be done. 
Step 12.Add a logger (NLog) to windows service project and log error to flat files.


