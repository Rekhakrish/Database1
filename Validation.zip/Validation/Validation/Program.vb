Imports System

Module Program

    Sub Main(args As String())
        Dim studentname As String
        Console.WriteLine("Enter the Studentname")
        studentname = Console.ReadLine()
        Dim validation As Studentnamevalidation = New Studentnamevalidation()
        If (validation.isValidStudentName(studentname)) Then
            Console.WriteLine("Given input's datatype is string")
        Else
            Console.WriteLine("value should not be empty or null .It should be only string")
        End If
    End Sub
End Module
