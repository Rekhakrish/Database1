﻿Imports System.Text.RegularExpressions

Public Class Studentnamevalidation
    Public studentName As String

    Public Function isValidStudentName(studentname As String) As Boolean


        If Not (String.IsNullOrEmpty(studentname)) Then
            If studentname.Length <= 50 And studentname.Length >= 1 Then
                If Regex.IsMatch(studentname, "^[a-z]+$", RegexOptions.IgnoreCase) Then
                    Return True
                Else
                    Return False
                End If
            Else
                Return False
            End If
        Else
            Return False
        End If

    End Function

End Class
